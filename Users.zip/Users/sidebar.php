<aside class="sidebar">
<div class="logo-container" onclick="window.location='http://localhost/myapp/" style="cursor: pointer;">
    <h1>وظفني</h1>
</div>

    <div class="user-profile">
        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div>
            <h3>أحمد محمد</h3>
            <span>مدير التوظيف</span>
        </div>
    </div>

    <nav class="nav-menu">
        <a href="http://localhost/myapp/" class="nav-item active">
            <i class="fas fa-home"></i>
            لوحة التحكم
        </a>
        <a href="http://localhost/myapp/jops/index.php" class="nav-item">
    <i class="fas fa-briefcase"></i>
     الوظائف
</a>
<a href="http://localhost/myapp/Users/index.php" class="nav-item">
    <i class="fas fa-briefcase"></i>
     لجنة التوظيف
</a>
        <a href="http://localhost/myapp/employees/index.php" class="nav-item">
            <i class="fas fa-users"></i>
            الموظفين 
            <span class="notification-badge">4</span>
        </a>
        <a href="http://localhost/myapp/interviews/index.php" class="nav-item">
            <i class="fas fa-user-tie"></i>
             مقابلات العميل
        </a>

    

    </nav>

    <button class="logout-btn">
        <i class="fas fa-sign-out-alt"></i>
        تسجيل الخروج
    </button>
</aside>